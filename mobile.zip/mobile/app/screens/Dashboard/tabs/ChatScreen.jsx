import { View, Text } from "react-native";

const ChatScreen = () => {
  return (
    <View className="flex flex-col items-center justify-center h-screen">
      <Text>ChatScreen</Text>
    </View>
  );
};

export default ChatScreen;
