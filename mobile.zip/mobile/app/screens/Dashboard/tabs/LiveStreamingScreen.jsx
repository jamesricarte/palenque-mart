import { View, Text } from "react-native";

const LiveStreamingScreen = () => {
  return (
    <View className="flex flex-col items-center justify-center h-screen">
      <Text>LiveStreamingScreen</Text>
    </View>
  );
};

export default LiveStreamingScreen;
